
-- Add new values to the care_action enum type
ALTER TYPE public.care_action ADD VALUE 'sunlight';
ALTER TYPE public.care_action ADD VALUE 'love';
